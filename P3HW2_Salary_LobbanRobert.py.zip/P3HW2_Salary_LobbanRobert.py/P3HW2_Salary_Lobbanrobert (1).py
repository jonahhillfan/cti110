
# CTI-110
# P3HW2 - Salary
# Robert Lobban
# 11/3/2022
#
#asks the input from the user of their name
#asks the input from the user of their hours worked
#asks the input from the user of their rate per hours they are payed
#varaible overtimehours= 0 for filler
#varaible overtimepay = 0 for filler
#if statement if worked_hours is greater than 40
#if worked_hours > 40: = true overtimehours=(worked_hours - 40) for the how much overtime hours worked
#if worked_hours > 40: = true overtimepay =((worked_hours - 40)*1.5*rate) rate fr how much you get paid for overtime
#if worked_hours > 40: = true reghourpay is 40 times rate because you cant have over 40 hours for overtime
#if worked_hours > 40: = true gross= overtimepay + reghourpay
#if worked_hours > 40: = false the reghourpay is wroked_hours times rate pay
#if worked_hours > 40: = false gross=(reghourpay)
#prints _ 50 times
#prints employee name and input from the user name
#prints hours worked, payrate, overtime, overtime pay, reghourpau , gross pay all on the same line
#prints _ 80 times
#prints worked_hours, rate, overtimehours, overtimepay, reghourpay, gross all on the same line
name = input('Enter your name: ')
worked_hours = float(input('Enter the ammount of hours you worked: '))
rate = float(input('What is your pay rate? '))
overtimehours=0
overtimepay=0
if worked_hours > 40:
    overtimehours=(worked_hours - 40)
    overtimepay =((worked_hours - 40)*1.5*rate)
    reghourpay =(40*rate)
    gross = overtimepay + reghourpay
else:
    reghourpay =(worked_hours *rate)
    gross=(reghourpay)
print(50*'_')
print('Employee name:', str(format(name)).rjust(10))
print(str('Hours Worked').rjust(1),str('Pay Rate').rjust(1),str('OverTime').rjust(1),str('OverTime Pay').rjust(1),str('RegHour Pay').rjust(1),str('Gross pay').rjust(1), sep='\t')
print(80*'-')
print(str(worked_hours).rjust(4),str(rate).rjust(15),str(overtimehours).rjust(15),str(overtimepay).rjust(15),str(reghourpay).rjust(15),str(gross).rjust(15), sep='\t')

