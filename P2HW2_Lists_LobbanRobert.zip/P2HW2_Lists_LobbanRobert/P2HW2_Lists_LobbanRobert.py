# CTI-110
# P2HW2 - List
# Robert Lobban
# 10/2/2022
# This program use is to get the avergage, highest, lowest, and sum grades using input from the user.
#input for modules 1 for the use to enter the grade for module 1
#input for modules 2 for the use to enter the grade for module 2
#input for modules 3 for the use to enter the grade for module 3
#input for modules 4 for the use to enter the grade for module 4
#input for modules 5 for the use to enter the grade for module 5
#input for modules 6 for the use to enter the grade for module 6
#variable master_module is a list of all the modules
#finds out the lowest grade using low of master module
#finds out the highest grade using max of master module
#finds out the total using sum of all the master module
#finds out the average from using total and lens to deivide master module
#print ---------Results---------
#prints the lowest grade scored for the modules and uses float to  convert it into a floating point number
#prints the highest grade scored for the modules and uses float to  convert it into a floating point number
#prints the sum of the grades from all the modules and uses float to  convert it into a floating point number
#prints the average of all modules and uses float to  convert it into a floating point number
#print ---------Results---------

Module1 = int(input('Enter grade for module 1:'))
Module2 = int(input('Enter grade for module 2:'))
Module3 = int(input('Enter grade for module 3:'))
Module4 = int(input('Enter grade for module 4:'))
Module5 = int(input('Enter grade for module 5:'))
Module6 = int(input('Enter grade for module 6:'))
master_module=[Module1, Module1, Module2, Module3, Module4, Module5 ,Module6]
low = min(master_module)
high = max(master_module) 
total = sum(master_module)
avg = total/len(master_module)
print('---------Results---------')
print('Lowest Grade:', float(low,))
print('Highest Grade:', float(high))
print('Sum of Grades:', float(total))
print('Average:', float(avg))
print('---------Results---------')



